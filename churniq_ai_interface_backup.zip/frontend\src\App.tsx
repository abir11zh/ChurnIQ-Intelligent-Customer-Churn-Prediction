import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "./components/AppShell";
import {
  AICopilot,
  Analytics,
  BatchPrediction,
  Campaigns,
  ContactSupport,
  CustomerDetails,
  CustomerList,
  CustomerSegmentation,
  Dashboard,
  ForgotPassword,
  HelpCenter,
  Insights,
  Landing,
  Login,
  ModelMonitoring,
  ModelPerformance,
  Notifications,
  Prediction,
  PredictionResult,
  Profile,
  Register,
  ResetPassword,
  RetentionCenter,
  Reports,
  SettingsPage,
  ShapExplanation,
  TeamManagement
} from "./pages/AppPages";
import { ProtectedRoute } from "./lib/auth";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/app" element={<ProtectedRoute><AppShell /></ProtectedRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="customers" element={<CustomerList />} />
        <Route path="customers/:id" element={<CustomerDetails />} />
        <Route path="segmentation" element={<CustomerSegmentation />} />
        <Route path="prediction" element={<Prediction />} />
        <Route path="prediction/result" element={<PredictionResult />} />
        <Route path="shap" element={<ShapExplanation />} />
        <Route path="batch" element={<BatchPrediction />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="model-performance" element={<ModelPerformance />} />
        <Route path="model-monitoring" element={<ModelMonitoring />} />
        <Route path="insights" element={<Insights />} />
        <Route path="copilot" element={<AICopilot />} />
        <Route path="retention" element={<RetentionCenter />} />
        <Route path="campaigns" element={<Campaigns />} />
        <Route path="reports" element={<Reports />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="team" element={<TeamManagement />} />
        <Route path="profile" element={<Profile />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="help" element={<HelpCenter />} />
        <Route path="support" element={<ContactSupport />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
