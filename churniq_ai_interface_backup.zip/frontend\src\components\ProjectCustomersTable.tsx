import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  useReactTable,
  type ColumnDef
} from "@tanstack/react-table";
import { Eye, Play, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { getCustomerSample, type ProjectCustomer } from "../lib/api";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

export function ProjectCustomersTable() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["customers-sample"],
    queryFn: () => getCustomerSample(12)
  });

  const columns = useMemo<ColumnDef<ProjectCustomer>[]>(
    () => [
      { accessorKey: "customer_id", header: "Customer ID" },
      { accessorKey: "name", header: "Name" },
      { accessorKey: "email", header: "Email" },
      { accessorKey: "contract", header: "Contract Type" },
      {
        accessorKey: "monthly_charges",
        header: "Monthly Charges",
        cell: ({ row }) => `$${row.original.monthly_charges.toFixed(2)}`
      },
      {
        accessorKey: "tenure",
        header: "Tenure",
        cell: ({ row }) => `${row.original.tenure} mo`
      },
      {
        accessorKey: "risk",
        header: "Risk Score",
        cell: ({ row }) => (
          <Badge tone={row.original.risk === "CRITICAL" || row.original.risk === "HIGH" ? "danger" : row.original.risk === "MEDIUM" ? "warning" : "success"}>
            {row.original.risk}
          </Badge>
        )
      },
      {
        accessorKey: "churn_probability",
        header: "Churn Probability",
        cell: ({ row }) => <span className="font-extrabold">{row.original.churn_probability}%</span>
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => (
          <div className="flex items-center gap-1">
            <Button asChild variant="ghost" size="icon" aria-label="View customer">
              <Link to={`/app/customers/${row.original.customer_id}`}><Eye className="h-4 w-4" /></Link>
            </Button>
            <Button variant="ghost" size="icon" aria-label="Predict customer"><Play className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" aria-label="Delete customer"><Trash2 className="h-4 w-4 text-danger" /></Button>
          </div>
        )
      }
    ],
    []
  );

  const table = useReactTable({
    data: data ?? [],
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel()
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2, 3].map((item) => <div key={item} className="h-14 animate-pulse rounded-xl bg-slate-100" />)}
      </div>
    );
  }

  if (isError || !data?.length) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-200 p-10 text-center">
        <p className="font-extrabold text-ink">No customers available</p>
        <p className="mt-2 text-sm text-muted">Start FastAPI or import a customer file to populate this table.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto scrollbar-thin">
      <table className="w-full min-w-[980px] text-left text-sm">
        <thead className="text-muted">
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th key={header.id} className="px-4 py-3 font-bold">
                  {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id} className="border-t border-slate-100">
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id} className="px-4 py-4">
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-5 flex items-center justify-between">
        <Button variant="outline" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>Previous</Button>
        <p className="text-sm font-semibold text-muted">Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}</p>
        <Button variant="outline" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>Next</Button>
      </div>
    </div>
  );
}
