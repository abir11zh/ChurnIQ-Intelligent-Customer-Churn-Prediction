import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";

export type Role = "Admin" | "Manager" | "Analyst" | "Viewer";

export type AuthUser = {
  name: string;
  email: string;
  role: Role;
};

type AuthContextValue = {
  user: AuthUser | null;
  signIn: (role?: Role) => void;
  signOut: () => void;
  setRole: (role: Role) => void;
};

const defaultUser: AuthUser = {
  name: "John Doe",
  email: "john@churniq.local",
  role: "Admin"
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => {
    const raw = window.localStorage.getItem("churniq:user");
    if (!raw) return defaultUser;
    try {
      return JSON.parse(raw) as AuthUser;
    } catch {
      window.localStorage.removeItem("churniq:user");
      return defaultUser;
    }
  });

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      signIn: (role = "Admin") => {
        const nextUser = { ...defaultUser, role };
        window.localStorage.setItem("churniq:user", JSON.stringify(nextUser));
        setUser(nextUser);
      },
      signOut: () => {
        window.localStorage.removeItem("churniq:user");
        setUser(null);
      },
      setRole: (role) => {
        const nextUser = { ...(user ?? defaultUser), role };
        window.localStorage.setItem("churniq:user", JSON.stringify(nextUser));
        setUser(nextUser);
      }
    }),
    [user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }
  return context;
}

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  return <>{children}</>;
}

export function RoleGuard({ allowed, children }: { allowed: Role[]; children: ReactNode }) {
  const { user } = useAuth();
  if (!user || !allowed.includes(user.role)) {
    return null;
  }
  return <>{children}</>;
}
