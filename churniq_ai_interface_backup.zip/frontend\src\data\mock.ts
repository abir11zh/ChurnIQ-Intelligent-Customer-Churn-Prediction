import {
  Activity,
  BarChart3,
  Bell,
  Bot,
  BrainCircuit,
  Building2,
  CheckCircle2,
  CreditCard,
  FileText,
  Gauge,
  Headphones,
  LayoutDashboard,
  LineChart,
  Megaphone,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Upload,
  Users
} from "lucide-react";

export const navItems = [
  { label: "Dashboard", href: "/app", icon: LayoutDashboard },
  { label: "Customers", href: "/app/customers", icon: Users },
  { label: "Segmentation", href: "/app/segmentation", icon: Search },
  { label: "Prediction", href: "/app/prediction", icon: Gauge },
  { label: "Model Performance", href: "/app/model-performance", icon: LineChart },
  { label: "Analytics", href: "/app/analytics", icon: BarChart3 },
  { label: "AI Insights", href: "/app/insights", icon: BrainCircuit },
  { label: "AI Copilot", href: "/app/copilot", icon: Bot },
  { label: "Retention", href: "/app/retention", icon: CheckCircle2 },
  { label: "Campaigns", href: "/app/campaigns", icon: Megaphone },
  { label: "Model Monitoring", href: "/app/model-monitoring", icon: Activity },
  { label: "Reports", href: "/app/reports", icon: FileText },
  { label: "Notifications", href: "/app/notifications", icon: Bell },
  { label: "Team", href: "/app/team", icon: ShieldCheck },
  { label: "Settings", href: "/app/settings", icon: Settings },
  { label: "Support", href: "/app/support", icon: Headphones }
];

export const landingFeatures = [
  { title: "Churn prediction", icon: Gauge, text: "Score customers with calibrated LightGBM risk thresholds." },
  { title: "SHAP explainability", icon: Sparkles, text: "Understand drivers like contract type, tenure and charges." },
  { title: "Retention workflows", icon: Megaphone, text: "Turn risk cohorts into targeted save campaigns." },
  { title: "Executive reports", icon: FileText, text: "Export revenue, churn and AI insight reports." }
];

export const kpis = [
  { label: "Total Customers", value: "7,043", delta: "+12.4%", icon: Users, tone: "primary" },
  { label: "Churn Rate", value: "26.5%", delta: "-3.1%", icon: Activity, tone: "danger" },
  { label: "Monthly Revenue", value: "$16.2M", delta: "+9.8%", icon: CreditCard, tone: "success" },
  { label: "High Risk Customers", value: "1,234", delta: "+4.6%", icon: Bell, tone: "warning" }
];

export const revenueTrend = [
  { month: "Jan", revenue: 11.8, churn: 32, customers: 6000 },
  { month: "Feb", revenue: 12.6, churn: 29, customers: 6210 },
  { month: "Mar", revenue: 13.9, churn: 31, customers: 6480 },
  { month: "Apr", revenue: 13.4, churn: 27, customers: 6720 },
  { month: "May", revenue: 14.8, churn: 30, customers: 6960 },
  { month: "Jun", revenue: 16.2, churn: 26.5, customers: 7043 }
];

export const riskMix = [
  { name: "Low", value: 385, color: "#22C55E" },
  { name: "Medium", value: 370, color: "#F59E0B" },
  { name: "High", value: 245, color: "#EF4444" },
  { name: "Critical", value: 82, color: "#6D5BFF" }
];

export const customers = [
  { id: "CUST_03246", name: "Sarah Johnson", email: "sarah@email.com", contract: "Month-to-month", risk: "CRITICAL", probability: 82, revenue: "$1200.50", status: "At risk" },
  { id: "CUST_18467", name: "Michael Chen", email: "m.chen@email.com", contract: "One year", risk: "HIGH", probability: 67, revenue: "$930.00", status: "Monitor" },
  { id: "CUST_02158", name: "Emily Davis", email: "emily@email.com", contract: "Two year", risk: "MEDIUM", probability: 44, revenue: "$780.00", status: "Active" },
  { id: "CUST_35249", name: "David Wilson", email: "david@email.com", contract: "Month-to-month", risk: "LOW", probability: 23, revenue: "$620.00", status: "Active" },
  { id: "CUST_93440", name: "Jennifer Lee", email: "jennifer@email.com", contract: "One year", risk: "LOW", probability: 18, revenue: "$1080.00", status: "Active" },
  { id: "CUST_33041", name: "Robert Taylor", email: "robert@email.com", contract: "Month-to-month", risk: "MEDIUM", probability: 58, revenue: "$640.00", status: "Monitor" }
];

export const shapFactors = [
  { feature: "Contract Type", value: 0.45, impact: "danger" },
  { feature: "Monthly Charges", value: 0.31, impact: "danger" },
  { feature: "No Tech Support", value: 0.15, impact: "danger" },
  { feature: "Tenure", value: -0.12, impact: "primary" },
  { feature: "Online Security", value: -0.08, impact: "primary" },
  { feature: "Has Dependents", value: -0.06, impact: "primary" }
];

export const insights = [
  { title: "High Risk Pattern Detected", text: "Customers with month-to-month contracts and high monthly charges are 2.8x more likely to churn.", icon: BrainCircuit, tag: "High impact" },
  { title: "Retention Opportunity", text: "Offering tech support to 245 customers could reduce churn by up to 14%.", icon: CheckCircle2, tag: "Medium impact" },
  { title: "Revenue Impact", text: "Preventing churn from high-value customers protects an estimated $2.4M ARR.", icon: CreditCard, tag: "High impact" },
  { title: "Best Performing Segment", text: "Two-year contract customers show the highest retention score at 92%.", icon: Building2, tag: "Positive" }
];

export const reports = [
  { name: "Churn Report", text: "Detailed churn analysis and risk scoring.", icon: FileText },
  { name: "Revenue Report", text: "MRR, ARR and revenue leakage.", icon: CreditCard },
  { name: "Customer Report", text: "Customer segmentation and lifecycle.", icon: Users },
  { name: "AI Insights Report", text: "Model explanations and recommendations.", icon: Bot }
];

export const activity = [
  "Sarah Johnson moved to critical risk",
  "245 customers added to Win-Back campaign",
  "Monthly benchmark report generated",
  "Model drift monitor checked source data",
  "Revenue risk alert sent to retention team"
];

export const uploadStats = [
  { label: "Total processed", value: "1,000" },
  { label: "High risk", value: "245" },
  { label: "Medium risk", value: "370" },
  { label: "Low risk", value: "385" }
];

export const helpTopics = [
  { title: "Getting started", icon: Search },
  { title: "Model training", icon: BrainCircuit },
  { title: "Managing predictions", icon: Gauge },
  { title: "Understanding SHAP", icon: BarChart3 },
  { title: "Best practices", icon: CheckCircle2 },
  { title: "Batch uploads", icon: Upload }
];
