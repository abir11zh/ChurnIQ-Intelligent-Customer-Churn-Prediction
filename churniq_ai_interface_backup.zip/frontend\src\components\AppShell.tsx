import { useEffect, useState } from "react";
import { Bell, Command, LogOut, Menu, Moon, Search, Sun, X } from "lucide-react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Logo } from "./Logo";
import { activity, navItems } from "../data/mock";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { cn } from "../lib/utils";
import { useAuth, type Role } from "../lib/auth";

export function AppShell() {
  const [commandOpen, setCommandOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const { user, setRole, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen(true);
      }
      if (event.key === "Escape") {
        setCommandOpen(false);
        setNotificationsOpen(false);
        setMobileOpen(false);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const nav = (
    <nav className="mt-8 space-y-1">
      {navItems.map((item) => (
        <NavLink
          key={item.href}
          to={item.href}
          end={item.href === "/app"}
          onClick={() => setMobileOpen(false)}
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted transition hover:bg-[#f6f4ff] hover:text-primary dark:text-slate-300 dark:hover:bg-white/10",
              isActive && "bg-[#f2efff] text-primary dark:bg-primary/20 dark:text-white"
            )
          }
        >
          <item.icon className="h-4 w-4 shrink-0" />
          <span className="truncate">{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );

  const openCommand = (href: string) => {
    navigate(href);
    setCommandOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#fbfbff] text-ink dark:bg-slate-950 dark:text-white">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 overflow-y-auto border-r border-slate-100 bg-white/82 p-5 backdrop-blur-xl dark:border-white/10 dark:bg-slate-950/90 lg:block">
        <Logo />
        {nav}
        <div className="mt-8 rounded-2xl bg-gradient-to-br from-primary to-secondary p-4 text-white shadow-soft">
          <p className="text-sm font-bold">AI model v2.0</p>
          <p className="mt-1 text-xs text-white/75">Project reports synced.</p>
        </div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-ink/40 lg:hidden" onClick={() => setMobileOpen(false)}>
          <aside className="h-full w-72 overflow-y-auto bg-white p-5 shadow-soft dark:bg-slate-950" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-center justify-between">
              <Logo />
              <Button variant="ghost" size="icon" onClick={() => setMobileOpen(false)} aria-label="Close menu">
                <X className="h-5 w-5" />
              </Button>
            </div>
            {nav}
          </aside>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-20 items-center justify-between border-b border-slate-100 bg-white/82 px-4 backdrop-blur-xl dark:border-white/10 dark:bg-slate-950/82 sm:px-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open menu" onClick={() => setMobileOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
            <button
              onClick={() => setCommandOpen(true)}
              className="relative hidden h-11 w-80 rounded-xl border border-slate-200 bg-white px-10 text-left text-sm text-muted shadow-sm transition hover:border-primary/30 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 sm:block"
            >
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              Search customers, campaigns...
              <span className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md bg-slate-100 px-2 py-0.5 text-xs font-bold text-muted dark:bg-white/10">Ctrl K</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" aria-label="Command palette" onClick={() => setCommandOpen(true)}>
              <Command className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Theme" onClick={() => setDarkMode((value) => !value)}>
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <div className="relative">
              <Button variant="ghost" size="icon" aria-label="Notifications" onClick={() => setNotificationsOpen((value) => !value)}>
                <Bell className="h-4 w-4" />
              </Button>
              {notificationsOpen && (
                <div className="absolute right-0 top-12 w-80 rounded-2xl border border-slate-100 bg-white p-3 shadow-soft dark:border-white/10 dark:bg-slate-900">
                  <p className="px-2 pb-2 text-sm font-extrabold">Notification Center</p>
                  {activity.slice(0, 4).map((item, index) => (
                    <button key={item} className="block w-full rounded-xl px-3 py-3 text-left text-sm hover:bg-[#f6f4ff] dark:hover:bg-white/10">
                      <span className="font-bold">{item}</span>
                      <span className="mt-1 block text-xs text-muted">{index + 2} minutes ago</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="ml-2 flex items-center gap-3 rounded-2xl border border-slate-100 bg-white px-3 py-2 shadow-sm dark:border-white/10 dark:bg-white/5">
              <div className="h-9 w-9 rounded-full bg-gradient-to-br from-amber-200 to-primary" />
              <div className="hidden sm:block">
                <p className="text-sm font-bold">{user?.name ?? "Guest"}</p>
                <select
                  value={user?.role ?? "Viewer"}
                  onChange={(event) => setRole(event.target.value as Role)}
                  className="bg-transparent text-xs font-semibold text-muted outline-none"
                  aria-label="Role"
                >
                  {["Admin", "Manager", "Analyst", "Viewer"].map((role) => <option key={role}>{role}</option>)}
                </select>
              </div>
              <Button variant="ghost" size="icon" aria-label="Sign out" onClick={() => { signOut(); navigate("/login"); }}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        <main className="p-4 sm:p-6">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
            <Outlet />
          </motion.div>
        </main>
      </div>

      {commandOpen && (
        <div className="fixed inset-0 z-50 grid place-items-start bg-ink/40 px-4 pt-24" onClick={() => setCommandOpen(false)}>
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto w-full max-w-2xl rounded-2xl border border-slate-100 bg-white p-4 shadow-soft dark:border-white/10 dark:bg-slate-900"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input autoFocus className="pl-10" placeholder="Search or jump to a ChurnIQ module..." />
            </div>
            <div className="mt-4 grid gap-2">
              {navItems.map((item) => (
                <button key={item.href} onClick={() => openCommand(item.href)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-bold hover:bg-[#f6f4ff] dark:hover:bg-white/10">
                  <item.icon className="h-4 w-4 text-primary" />
                  {item.label}
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
