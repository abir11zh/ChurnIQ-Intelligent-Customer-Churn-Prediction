import { cn } from "../../lib/utils";
import type { ReactNode } from "react";

const tones = {
  neutral: "bg-slate-100 text-slate-600",
  success: "bg-green-50 text-green-600",
  warning: "bg-amber-50 text-amber-600",
  danger: "bg-red-50 text-red-600",
  primary: "bg-[#f2efff] text-primary"
};

export function Badge({
  tone = "neutral",
  className,
  children
}: {
  tone?: keyof typeof tones;
  className?: string;
  children: ReactNode;
}) {
  return <span className={cn("inline-flex rounded-full px-2.5 py-1 text-xs font-bold", tones[tone], className)}>{children}</span>;
}
