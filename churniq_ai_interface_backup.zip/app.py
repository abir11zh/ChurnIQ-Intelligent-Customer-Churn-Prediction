"""
FastAPI — Churn Prediction REST API
====================================
Run: uvicorn api.app:app --host 0.0.0.0 --port 8000
Docs: http://localhost:8000/docs
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, validator

import sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent.parent))

from src.config import MODEL_PATH, THRESHOLD_PATH
from src.inference import predict_single, classify_risk

logger = logging.getLogger("churn_api")

# ─── App Setup ───────────────────────────────────────────────────────────────

app = FastAPI(
    title="ChurnIQ AI API",
    description="Production-ready churn prediction API powering the ChurnIQ AI SaaS interface",
    version="2.0.0",
)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "WA_Fn-UseC_-Telco-Customer-Churn.csv"
FRONTEND_DIR = BASE_DIR / "frontend"
MODEL_REGISTRY_PATH = BASE_DIR / "models" / "model_registry.pkl"
TRAINING_REPORT_PATH = BASE_DIR / "reports" / "training_report.json"
BENCHMARK_PATH = BASE_DIR / "results" / "final_benchmark.csv"
SHAP_FEATURES_PATH = BASE_DIR / "reports" / "shap_top20_features.csv"
REPORTS_DIR = BASE_DIR / "reports"

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5173",
        "http://localhost:5173",
        "http://127.0.0.1:4173",
        "http://localhost:4173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model at startup
model = None
config = None
model_error = None
model_registry = None


@app.on_event("startup")
def load_model():
    global model, config, model_error, model_registry
    model_error = None
    model_registry = None
    try:
        with open(THRESHOLD_PATH) as f:
            config = json.load(f)
    except Exception as e:
        model_error = f"Failed to load threshold config: {type(e).__name__}: {e}"
        logger.error(model_error)

    try:
        if MODEL_REGISTRY_PATH.exists():
            model_registry = joblib.load(MODEL_REGISTRY_PATH)
            default_name = model_registry.get("default_model")
            registry_models = model_registry.get("models", {})
            model = registry_models.get(default_name) or next(iter(registry_models.values()))
            logger.info("Model registry loaded successfully")
        else:
            model = joblib.load(MODEL_PATH)
            logger.info("Model loaded successfully")
    except Exception as e:
        model = None
        detail = f"{type(e).__name__}: {e}" if str(e) else type(e).__name__
        source = MODEL_REGISTRY_PATH if MODEL_REGISTRY_PATH.exists() else MODEL_PATH
        model_error = f"Failed to load model from {source}: {detail}"
        logger.error(model_error)


# ─── Request/Response Models ────────────────────────────────────────────────

class CustomerFeatures(BaseModel):
    tenure: float = Field(..., ge=0, le=72, description="Months as customer")
    MonthlyCharges: float = Field(..., ge=0, le=200, description="Monthly bill")
    TotalCharges: float = Field(..., ge=0, description="Total charges to date")
    gender: str = Field(..., description="Male or Female")
    SeniorCitizen: str = Field(..., description="Yes or No")
    Partner: str = Field(..., description="Yes or No")
    Dependents: str = Field(..., description="Yes or No")
    PhoneService: str = Field(..., description="Yes or No")
    MultipleLines: str = Field(default="No")
    InternetService: str = Field(default="DSL")
    OnlineSecurity: str = Field(default="No")
    OnlineBackup: str = Field(default="No")
    DeviceProtection: str = Field(default="No")
    TechSupport: str = Field(default="No")
    StreamingTV: str = Field(default="No")
    StreamingMovies: str = Field(default="No")
    Contract: str = Field(default="Month-to-month")
    PaperlessBilling: str = Field(default="Yes")
    PaymentMethod: str = Field(default="Electronic check")
    model_name: Optional[str] = Field(default=None, description="Optional model name from /models")
    
    @validator("gender")
    def validate_gender(cls, v):
        if v not in ("Male", "Female"):
            raise ValueError("gender must be Male or Female")
        return v
    
    @validator("Contract")
    def validate_contract(cls, v):
        valid = ("Month-to-month", "One year", "Two year")
        if v not in valid:
            raise ValueError(f"Contract must be one of {valid}")
        return v

    class Config:
        json_schema_extra = {
            "example": {
                "tenure": 5,
                "MonthlyCharges": 70.0,
                "TotalCharges": 350.0,
                "gender": "Male",
                "SeniorCitizen": "No",
                "Partner": "No",
                "Dependents": "No",
                "PhoneService": "Yes",
                "MultipleLines": "No",
                "InternetService": "Fiber optic",
                "OnlineSecurity": "No",
                "OnlineBackup": "No",
                "DeviceProtection": "No",
                "TechSupport": "No",
                "StreamingTV": "No",
                "StreamingMovies": "No",
                "Contract": "Month-to-month",
                "PaperlessBilling": "Yes",
                "PaymentMethod": "Electronic check",
            }
        }


class PredictionResponse(BaseModel):
    churn_probability: float
    will_churn: bool
    risk_level: str
    recommendation: str
    confidence: float
    threshold_used: float
    model_version: str
    model_name: str
    model_source: str
    scored_at: str


class CopilotRequest(BaseModel):
    message: str = Field(..., min_length=2, max_length=800)


def _load_customer_data() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise HTTPException(status_code=404, detail="Customer dataset not found")
    data = pd.read_csv(DATA_PATH)
    data["TotalCharges"] = pd.to_numeric(data.get("TotalCharges"), errors="coerce").fillna(0)
    return data


def _safe_number(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        if np.isnan(number) or np.isinf(number):
            return default
        return number
    except Exception:
        return default


def _pct(value: Any) -> float:
    return round(_safe_number(value) * 100, 1)


def _load_training_report() -> dict:
    if not TRAINING_REPORT_PATH.exists():
        return {}
    try:
        with open(TRAINING_REPORT_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        logger.warning("Could not read training report: %s", exc)
        return {}


def _load_benchmark_rows() -> list[dict]:
    if not BENCHMARK_PATH.exists():
        return []
    try:
        frame = pd.read_csv(BENCHMARK_PATH)
        frame = frame.replace({np.nan: None})
        return frame.to_dict(orient="records")
    except Exception as exc:
        logger.warning("Could not read benchmark results: %s", exc)
        return []


def _load_shap_features(limit: int = 12) -> list[dict]:
    if not SHAP_FEATURES_PATH.exists():
        return []
    try:
        frame = pd.read_csv(SHAP_FEATURES_PATH).head(limit)
        feature_col = "Feature" if "Feature" in frame.columns else frame.columns[1]
        value_col = "Mean |SHAP|" if "Mean |SHAP|" in frame.columns else frame.columns[-1]
        return [
            {
                "feature": str(row[feature_col]).replace("_", " "),
                "importance": round(_safe_number(row[value_col]), 4),
            }
            for _, row in frame.iterrows()
        ]
    except Exception as exc:
        logger.warning("Could not read SHAP feature file: %s", exc)
        return []


def _model_config() -> dict:
    global config
    if config is not None:
        return config
    try:
        with open(THRESHOLD_PATH) as f:
            config = json.load(f)
        return config
    except Exception:
        return {"threshold": 0.5, "version": "fallback", "model": "Heuristic fallback", "metrics": {}}


def _registry_models() -> dict:
    if not model_registry:
        return {}
    return model_registry.get("models", {}) or {}


def _registry_metrics() -> list[dict]:
    if not model_registry:
        return []
    return model_registry.get("metrics", []) or []


def _available_models() -> list[dict]:
    registry_models = _registry_models()
    registry_metric_map = {row.get("model"): row for row in _registry_metrics()}
    rows = []
    for name in registry_models:
        metrics = registry_metric_map.get(name, {})
        rows.append(
            {
                "name": name,
                "loaded": True,
                "is_default": name == (model_registry or {}).get("default_model"),
                "roc_auc": _pct(metrics.get("test_auc_roc", 0)),
                "precision": _pct(metrics.get("test_precision", 0)),
                "recall": _pct(metrics.get("test_recall", 0)),
                "f1": _pct(metrics.get("test_f1", 0)),
            }
        )

    if not rows and model is not None:
        cfg = _model_config()
        rows.append(
            {
                "name": cfg.get("model", "Default model"),
                "loaded": True,
                "is_default": True,
                "roc_auc": _pct(cfg.get("metrics", {}).get("test_auc", 0)),
                "precision": _pct(cfg.get("metrics", {}).get("test_precision", 0)),
                "recall": _pct(cfg.get("metrics", {}).get("test_recall", 0)),
                "f1": _pct(cfg.get("metrics", {}).get("test_f1", 0)),
            }
        )
    return rows


def _get_prediction_model(model_name: Optional[str]):
    registry_models = _registry_models()
    if registry_models:
        selected_name = model_name or model_registry.get("default_model")
        if selected_name not in registry_models:
            available = ", ".join(registry_models.keys())
            raise HTTPException(status_code=404, detail=f"Model '{selected_name}' not found. Available models: {available}")
        return selected_name, registry_models[selected_name], "registry"

    cfg = _model_config()
    return cfg.get("model", "Default model"), model, "single"


def _heuristic_predict(customer: CustomerFeatures) -> dict:
    cfg = _model_config()
    score = 0.08
    score += 0.26 if customer.Contract == "Month-to-month" else 0.08 if customer.Contract == "One year" else -0.04
    score += 0.18 if customer.MonthlyCharges >= 75 else 0.1 if customer.MonthlyCharges >= 55 else 0.02
    score += 0.14 if customer.TechSupport == "No" else -0.04
    score += 0.1 if customer.OnlineSecurity == "No" else -0.03
    score += 0.1 if customer.tenure <= 12 else 0.04 if customer.tenure <= 24 else -0.06
    score += 0.05 if customer.PaymentMethod == "Electronic check" else 0
    score += 0.04 if customer.PaperlessBilling == "Yes" else 0
    score += 0.04 if customer.SeniorCitizen == "Yes" else 0
    probability = float(min(0.96, max(0.04, score)))
    threshold = float(cfg.get("threshold", 0.5) or 0.5)
    risk_level, recommendation = classify_risk(probability)
    confidence = min(abs(probability - threshold) / max(threshold, 1 - threshold), 1.0)
    return {
        "churn_probability": round(probability, 4),
        "will_churn": probability >= threshold,
        "risk_level": risk_level,
        "recommendation": recommendation,
        "confidence": round(float(confidence), 4),
        "threshold_used": threshold,
        "model_version": f"{cfg.get('version', 'fallback')} heuristic",
        "model_name": "Heuristic fallback",
        "model_source": "heuristic",
        "scored_at": datetime.now().isoformat(),
    }


# ─── Endpoints ───────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "ok",
        "model_loaded": model is not None,
        "model_version": _model_config().get("version", "unknown"),
        "model_registry_loaded": bool(_registry_models()),
        "available_models": [item["name"] for item in _available_models()],
        "model_error": model_error,
        "fallback_prediction_enabled": model is None,
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/dashboard-summary")
async def dashboard_summary():
    """Return project-backed dashboard metrics for the ChurnIQ interface."""
    data = _load_customer_data()
    total_customers = int(len(data))
    churn_rate = float((data["Churn"].eq("Yes").mean() * 100).round(1)) if "Churn" in data else 0.0
    monthly_revenue = float(data["MonthlyCharges"].sum()) if "MonthlyCharges" in data else 0.0
    avg_tenure = float(data["tenure"].mean().round(1)) if "tenure" in data else 0.0
    high_risk_customers = int((data.get("Contract", pd.Series(dtype=str)).eq("Month-to-month")).sum())
    cfg = _model_config()
    threshold = cfg.get("threshold")
    metrics = cfg.get("metrics", {})
    prediction_accuracy = round(float(metrics.get("test_auc", 0.94)) * 100, 1)

    return {
        "total_customers": total_customers,
        "churn_rate": churn_rate,
        "monthly_revenue": round(monthly_revenue, 2),
        "avg_tenure": avg_tenure,
        "high_risk_customers": high_risk_customers,
        "prediction_accuracy": prediction_accuracy,
        "retention_score": round(100 - churn_rate, 1),
        "threshold": threshold,
        "model": cfg.get("model", "Heuristic fallback") if model is not None else f"{cfg.get('model', 'Model')} unavailable",
        "model_version": cfg.get("version", "fallback"),
    }


@app.get("/customers-sample")
async def customers_sample(limit: int = 10):
    """Return a small customer sample shaped for the frontend table."""
    data = _load_customer_data().head(max(1, min(limit, 50))).copy()
    rows = []
    for _, row in data.iterrows():
        monthly = float(row.get("MonthlyCharges", 0))
        tenure = float(row.get("tenure", 0))
        contract = str(row.get("Contract", "Unknown"))
        probability = min(95, max(8, int((monthly / 2.2) + (25 if contract == "Month-to-month" else 4) - (tenure / 3))))
        risk = "CRITICAL" if probability >= 80 else "HIGH" if probability >= 60 else "MEDIUM" if probability >= 40 else "LOW"
        rows.append(
            {
                "customer_id": str(row.get("customerID", "")),
                "name": f"Customer {row.get('customerID', '')}",
                "email": f"{str(row.get('customerID', 'customer')).lower()}@churniq.local",
                "contract": contract,
                "monthly_charges": monthly,
                "tenure": tenure,
                "risk": risk,
                "churn_probability": probability,
            }
        )
    return {"customers": rows}


@app.post("/predict", response_model=PredictionResponse)
async def predict(customer: CustomerFeatures):
    """Predict churn probability for a single customer."""
    if model is None:
        return PredictionResponse(**_heuristic_predict(customer))
    
    try:
        selected_name, selected_model, model_source = _get_prediction_model(customer.model_name)
        payload = customer.dict(exclude={"model_name"})
        result = predict_single(payload, model=selected_model, config=config)
        result["model_name"] = selected_name
        result["model_source"] = model_source
        return PredictionResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/models")
async def models():
    """Return all loadable models available for real manual predictions."""
    cfg = _model_config()
    return {
        "default_model": (model_registry or {}).get("default_model", cfg.get("model", "Default model")),
        "version": (model_registry or {}).get("version", cfg.get("version", "unknown")),
        "trained_on": (model_registry or {}).get("trained_on", cfg.get("trained_on")),
        "threshold": (model_registry or {}).get("threshold", cfg.get("threshold", 0.5)),
        "models": _available_models(),
        "registry_loaded": bool(_registry_models()),
        "model_error": model_error,
    }


@app.get("/model-info")
async def model_info():
    """Return model metadata and performance metrics."""
    cfg = _model_config()
    return {
        **cfg,
        "model_loaded": model is not None,
        "model_registry_loaded": bool(_registry_models()),
        "available_models": _available_models(),
        "model_error": model_error,
        "fallback_prediction_enabled": model is None,
    }


@app.get("/model-performance")
async def model_performance():
    """Return leaderboard, best-model metrics and feature impact from project reports."""
    report = _load_training_report()
    benchmark_rows = _load_benchmark_rows()
    report_rows = report.get("all_results", [])
    registry_rows = _registry_metrics()
    rows = registry_rows or report_rows or benchmark_rows

    leaderboard = []
    for item in rows:
        auc = item.get("test_auc_roc", item.get("roc_auc", item.get("test_auc", 0)))
        leaderboard.append(
            {
                "model": str(item.get("model", "Unknown")),
                "accuracy": _pct(item.get("test_accuracy", item.get("accuracy", 0))),
                "precision": _pct(item.get("test_precision", item.get("precision", 0))),
                "recall": _pct(item.get("test_recall", item.get("recall", 0))),
                "f1": _pct(item.get("test_f1", item.get("f1", 0))),
                "roc_auc": _pct(auc),
                "pr_auc": _pct(item.get("test_pr_auc", item.get("pr_auc", 0))),
                "business_cost": int(_safe_number(item.get("business_cost", 0))),
                "overfit_status": str(item.get("overfit_status", "N/A")),
                "loaded": str(item.get("model", "Unknown")) in _registry_models(),
            }
        )

    leaderboard = sorted(leaderboard, key=lambda row: row["roc_auc"], reverse=True)
    best_model_name = str((model_registry or {}).get("default_model") or report.get("best_model") or (leaderboard[0]["model"] if leaderboard else _model_config().get("model", "Unknown")))
    best_row = next((row for row in leaderboard if row["model"] == best_model_name), leaderboard[0] if leaderboard else {})
    shap_features = _load_shap_features()

    return {
        "best_model": best_model_name,
        "trained_on": (model_registry or {}).get("trained_on") or report.get("trained_on") or _model_config().get("trained_on"),
        "optimal_threshold": round(_safe_number((model_registry or {}).get("threshold", report.get("optimal_threshold", _model_config().get("threshold", 0.5)))), 2),
        "leaderboard": leaderboard[:20],
        "best_metrics": best_row,
        "feature_impact": report.get("feature_impact", [])[:8],
        "shap_features": shap_features,
        "model_loaded": model is not None,
        "model_registry_loaded": bool(_registry_models()),
        "available_models": _available_models(),
        "fallback_prediction_enabled": model is None,
    }


@app.get("/segmentation-summary")
async def segmentation_summary():
    """Return project-backed customer segments for lifecycle and churn analysis."""
    data = _load_customer_data().copy()
    data["MonthlyCharges"] = pd.to_numeric(data.get("MonthlyCharges"), errors="coerce").fillna(0)
    data["tenure"] = pd.to_numeric(data.get("tenure"), errors="coerce").fillna(0)
    data["TotalCharges"] = pd.to_numeric(data.get("TotalCharges"), errors="coerce").fillna(0)

    def assign_segment(row: pd.Series) -> str:
        contract = str(row.get("Contract", ""))
        tenure = _safe_number(row.get("tenure"))
        monthly = _safe_number(row.get("MonthlyCharges"))
        churn = str(row.get("Churn", "No"))
        if monthly >= 80 and tenure >= 24:
            return "VIP"
        if contract == "Month-to-month" and (churn == "Yes" or monthly >= 70 or tenure <= 18):
            return "At Risk"
        if tenure <= 12:
            return "New"
        if contract == "Two year" or tenure >= 48:
            return "Loyal"
        return "Core"

    data["Segment"] = data.apply(assign_segment, axis=1)
    segment_rows = []
    for segment, group in data.groupby("Segment"):
        churn_rate = group["Churn"].eq("Yes").mean() * 100 if "Churn" in group else 0
        segment_rows.append(
            {
                "name": segment,
                "customers": int(len(group)),
                "churn_rate": round(float(churn_rate), 1),
                "avg_monthly_charge": round(float(group["MonthlyCharges"].mean()), 2),
                "avg_tenure": round(float(group["tenure"].mean()), 1),
                "revenue": round(float(group["MonthlyCharges"].sum()), 2),
                "priority": "High" if segment == "At Risk" else "Medium" if segment in ("VIP", "New") else "Stable",
            }
        )

    scatter = []
    sampled = data.sort_values("MonthlyCharges", ascending=False).head(120)
    for _, row in sampled.iterrows():
        scatter.append(
            {
                "customer_id": str(row.get("customerID", "")),
                "segment": str(row.get("Segment", "Core")),
                "tenure": round(_safe_number(row.get("tenure")), 1),
                "monthly_charges": round(_safe_number(row.get("MonthlyCharges")), 2),
                "total_charges": round(_safe_number(row.get("TotalCharges")), 2),
                "churned": str(row.get("Churn", "No")) == "Yes",
            }
        )

    contract_mix = (
        data.groupby("Contract").size().reset_index(name="customers").replace({np.nan: None}).to_dict(orient="records")
        if "Contract" in data
        else []
    )

    return {
        "segments": sorted(segment_rows, key=lambda row: row["customers"], reverse=True),
        "scatter": scatter,
        "contract_mix": contract_mix,
        "recommendations": [
            "Prioritize month-to-month customers with high monthly charges.",
            "Move VIP customers toward annual contracts with premium support.",
            "Use onboarding journeys for new customers before month 12.",
        ],
    }


@app.get("/model-monitoring")
async def model_monitoring():
    """Return operational model health, drift and data quality indicators."""
    data = _load_customer_data()
    report = _load_training_report()
    cfg = _model_config()
    churn_rate = float(data["Churn"].eq("Yes").mean() * 100) if "Churn" in data else 0
    missing_total = int(data.isna().sum().sum())
    model_age_days = None
    trained_on = report.get("trained_on") or cfg.get("trained_on")
    if trained_on:
        try:
            model_age_days = (datetime.now() - datetime.fromisoformat(str(trained_on))).days
        except Exception:
            model_age_days = None

    drift_score = round(abs(churn_rate - 26.5) / 100, 3)
    drift_status = "Stable" if drift_score < 0.05 else "Watch"
    alerts = []
    if model is None:
        alerts.append("Model artifact unavailable; API is using heuristic fallback scoring.")
    if missing_total:
        alerts.append(f"Dataset contains {missing_total} missing values after loading.")
    if model_age_days is not None and model_age_days > 30:
        alerts.append("Model retraining window is due.")
    if not alerts:
        alerts.append("No critical monitoring alerts detected.")

    return {
        "status": "Fallback" if model is None else "Healthy",
        "model_loaded": model is not None,
        "model_error": model_error,
        "fallback_prediction_enabled": model is None,
        "model_version": cfg.get("version", "unknown"),
        "trained_on": trained_on,
        "model_age_days": model_age_days,
        "monitored_at": datetime.now().isoformat(),
        "prediction_volume": int(len(data)),
        "drift": {
            "score": drift_score,
            "status": drift_status,
            "baseline_churn_rate": 26.5,
            "current_churn_rate": round(churn_rate, 1),
        },
        "data_quality": {
            "rows": int(len(data)),
            "columns": int(len(data.columns)),
            "missing_values": missing_total,
            "duplicate_customers": int(data.duplicated(subset=["customerID"]).sum()) if "customerID" in data else 0,
        },
        "alerts": alerts,
    }


@app.get("/reports-index")
async def reports_index():
    """List generated reports and visual artifacts available in the project."""
    if not REPORTS_DIR.exists():
        return {"reports": []}
    items = []
    for path in sorted(REPORTS_DIR.glob("*")):
        if path.is_file() and path.suffix.lower() in {".md", ".json", ".csv", ".png"}:
            items.append(
                {
                    "name": path.name,
                    "type": path.suffix.lower().lstrip("."),
                    "size_kb": round(path.stat().st_size / 1024, 1),
                    "updated_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
                }
            )
    return {"reports": items}


@app.post("/ai-copilot")
async def ai_copilot(payload: CopilotRequest):
    """Rule-based local assistant for churn analysis, reports and retention planning."""
    message = payload.message.lower()
    summary = await dashboard_summary()
    performance = await model_performance()

    if any(word in message for word in ("retention", "campaign", "save", "offer")):
        answer = (
            "Focus first on month-to-month customers with high monthly charges and no support services. "
            "A discount plus tech-support bundle should target the highest-risk cohort before broad campaigns."
        )
        actions = ["Create Win-Back campaign", "Filter At Risk segment", "Export retention report"]
    elif any(word in message for word in ("model", "performance", "auc", "accuracy")):
        best = performance.get("best_metrics", {})
        answer = (
            f"The strongest tracked model is {performance.get('best_model')} with ROC-AUC "
            f"{best.get('roc_auc', 'N/A')}%. Use the threshold {performance.get('optimal_threshold')} for risk decisions."
        )
        actions = ["Open Model Performance", "Check monitoring alerts", "Review SHAP drivers"]
    elif any(word in message for word in ("segment", "customer", "cohort")):
        answer = (
            "Segment customers by contract, tenure and monthly charges. The At Risk cohort needs immediate action, "
            "VIP customers need proactive service, and new customers need onboarding nudges."
        )
        actions = ["Open Segmentation", "Inspect customer list", "Create cohort export"]
    elif any(word in message for word in ("report", "export", "download")):
        answer = (
            "Generate an executive report with churn rate, protected revenue, model leaderboard and top SHAP features. "
            "The reports folder already contains markdown, CSV and PNG artifacts from the training workflow."
        )
        actions = ["Open Reports", "Download AI insights", "Review training report"]
    else:
        answer = (
            f"Current dataset contains {summary['total_customers']} customers with {summary['churn_rate']}% churn. "
            "Ask about model performance, segments, retention campaigns or reports for a focused recommendation."
        )
        actions = ["Open dashboard", "Run single prediction", "Review insights"]

    return {
        "answer": answer,
        "suggested_actions": actions,
        "sources": ["WA_Fn-UseC_-Telco-Customer-Churn.csv", "training_report.json", "threshold_config.json"],
        "confidence": 0.86,
        "generated_at": datetime.now().isoformat(),
    }


@app.get("/ui")
async def churniq_ui():
    """Open the ChurnIQ AI static preview bundled with the project."""
    return RedirectResponse(url="/ui/preview.html")


if FRONTEND_DIR.exists():
    app.mount("/ui", StaticFiles(directory=FRONTEND_DIR, html=True), name="churniq-ui")
